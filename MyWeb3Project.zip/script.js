document.addEventListener('DOMContentLoaded', () => {
  console.log("Web3 Project Loaded");
});
